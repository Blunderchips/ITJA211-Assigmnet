 _     _ _                           ______             _    _               _____           _                 
| |   (_) |                          | ___ \           | |  (_)             /  ___|         | |                
| |    _| |__  _ __ __ _ _ __ _   _  | |_/ / ___   ___ | | ___ _ __   __ _  \ `--. _   _ ___| |_ ___ _ __ ___  
| |   | | '_ \| '__/ _` | '__| | | | | ___ \/ _ \ / _ \| |/ / | '_ \ / _` |  `--. \ | | / __| __/ _ \ '_ ` _ \ 
| |___| | |_) | | | (_| | |  | |_| | | |_/ / (_) | (_) |   <| | | | | (_| | /\__/ / |_| \__ \ ||  __/ | | | | |
\_____/_|_.__/|_|  \__,_|_|   \__, | \____/ \___/ \___/|_|\_\_|_| |_|\__, | \____/ \__, |___/\__\___|_| |_| |_|
                               __/ |                                  __/ |         __/ |                      
                              |___/                                  |___/         |___/                       

Introduction to Java Assigment (ITJA211) - 2017
Matthew Van der Bijl 
Student number: xq9x3wv31

The folder named 'ITJA211_Assigment_Matthew_Van_der_Bijl_xq9x3wv31' is a Netbeans project that contains all programing done for this assigment.
Question 1 and 2 have been placed in a seperate package to Question 3.

The 'lib' folder contains the required libary.
The folder named 'screenshots' contains various screenshot of the assigment.
The folder named 'javadoc' some documentation for the project.

The assigments specification (ITJA211 - Assignment - Specification (V1.0) and module outline (ITJA211 - Module Outline (V1.0)) for ITJA211 have also be included.
Turnitin digital receipt has been included - receipt_Introduction to Java - Matthew Van der Bijl (xq9x3wv31) (2nd Draft).pdf

Matthew Van der Bijl (matthewvdbijl@gmail.com)
30/03/2017